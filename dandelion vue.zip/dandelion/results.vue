<template>
  <v-card class="fill-height align-stretch">
    <v-tabs v-model="tab">
      <v-btn icon color="pink" class="mx-5 mt-2" @click="refreshCharts()">
        <v-icon>mdi-cached</v-icon>
      </v-btn>
      <v-tab v-for="label in tabLabels" :key="label">
        {{ label.replace(/_/g, ' ') }}
      </v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item
        v-for="(label, index) in tabLabels"
        :key="label"
        :transition="false"
        eager
        class="hidden"
        active-class="displayed"
      >
        <v-container
          v-if="!resultsReady"
          class="fill-height d-flex flex-column align-center justify-center"
        >
          <v-progress-circular indeterminate size="64"></v-progress-circular>
          <v-card-title
            >LOADING... {{ analysisRemaining }} /
            {{ selectedEpws.length }} files remaining</v-card-title
          >
        </v-container>
        <v-card flat class="fill-height" :id="label + 'card'">
          <div :id="label + '-chart'" class="svg-container">
            <div v-for="epw in selectedEpws" :key="epw._id">
              <div class="my-10">
                <v-card-title v-show="resultsReady">
                  {{ epw.name }} - {{ epw.period }} {{ chartTitles[index] }}
                </v-card-title>
                <v-card-text class="py-0">
                  <div :id="`${label}-${epw._id}`"></div>
                </v-card-text>
                <v-card-text class="py-0" v-if="resultsReady">
                  <div v-if="label == 'UTCI_Annual_Percentage'">
                    <v-card-title class="overline"
                      >Annual percentages</v-card-title
                    >
                    <v-row class="ml-16 mr-12" no-gutters>
                      <v-col
                        v-for="(value, index) in epw.object.utciResults
                          .comfortRatingDescriptivePercentage"
                        :key="value"
                      >
                        <v-card outlined tile>
                          <v-card-subtitle class="subtitle-2 py-0 pt-3">
                            {{ value }}
                          </v-card-subtitle>
                          <v-card-text
                            >{{ epw.object.utciResults.comfortRanges[index] }}
                          </v-card-text>
                        </v-card>
                      </v-col>
                      <v-col cols="1"> </v-col>
                    </v-row>
                  </div>
                  <div v-if="label == 'UTCI_Stress_Categories'">
                    <v-card-title>Comfort category definition</v-card-title>
                    <v-row class="ml-16 mr-12" no-gutters>
                      <v-col
                        v-for="(value, index) in epw.object.utciResults
                          .comfortRatingDescriptive"
                        :key="value"
                      >
                        <v-card outlined tile>
                          <div
                            :style="{
                              backgroundColor: comfortRatingLegendColors[index],
                              height: '30px'
                            }"
                          ></div>
                          <v-card-title class="text-subtitle-2 py-0 pt-3">
                            {{ value }}
                          </v-card-title>
                          <v-card-text
                            >{{
                              epw.object.utciResults
                                .comfortRatingDescriptiveDef[index]
                            }}
                          </v-card-text>
                        </v-card>
                      </v-col>
                      <v-col cols="1"> </v-col>
                    </v-row>
                  </div>
                </v-card-text>
              </div>
            </div>
          </div>
        </v-card>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>
<script>
import { mapGetters } from 'vuex'
import * as epwCharts from '~/plugins/dandelion/epwCharts.js'
export default {
  data() {
    return {
      tab: null,
      chartsVisible: true,
      chartError: {},
      chartsAtTab: {
        Temperature: [epwCharts.epwTempFloodPlot],
        Humidity: [epwCharts.epwRHFloodPlot],
        Cloud_cover: [epwCharts.epwCloudFloodPlot],
        UTCI_Annual_Percentage: [epwCharts.epwUTCIFloodPlot],
        UTCI_Stress_Categories: [epwCharts.epwComfortFloodPlot],
        Wind: [epwCharts.epwWindRose]
      },
      tabLabels: [
        'Temperature',
        'Humidity',
        'Cloud_cover',
        'UTCI_Annual_Percentage',
        'UTCI_Stress_Categories',
        'Wind'
      ],
      chartTitles: [
        'Drybulb temperature',
        'Relative humidity',
        'Total sky cover',
        'Universal thermal comfort index',
        'Universal thermal comfort index',
        'Wind rose'
      ],
      comfortRatingLegendColors: [
        '#b12224',
        '#ea2b24',
        '#ee8522',
        '#53b848',
        '#68b8e7',
        '#4b62ad',
        '#4252a4'
      ],
      utciLegendColors: [
        '#2c2977',
        '#38429b',
        '#4252a4',
        '#4b62ad',
        '#68b8e7',
        '#53b848',
        'darkorange',
        'red',
        'firebrick',
        'maroon'
      ]
    }
  },
  watch: {
    tab(newTab, oldTab) {
      // if (oldTab == null) return
      // this.hideCharts(this.tabLabels[oldTab])
      // setTimeout(() => {
      //   this.showCharts(this.tabLabels[newTab])
      // }, 300 * this.selectedEpws.length)
    },
    displayMode(newMode) {
      if (newMode == 'results' && this.resultsReady) {
        setTimeout(() => {
          this.showCharts(this.tabName)
        }, 200 * this.selectedEpws.length)
      } else if (newMode == 'map') {
        this.hideCharts(this.tabName)
      }
    },
    resultsReady(newResults) {
      if (!newResults) return

      // console.log('refeshign charts')
      this.refreshCharts()
    }
  },
  computed: {
    ...mapGetters({
      analysisRemaining: 'dandelion/amountAnalysing',
      resultsReady: 'dandelion/resultsReady',
      selectedEpws: 'dandelion/selectedEpws',
      displayMode: 'dandelion/displayMode'
    }),
    tabName() {
      return this.tabLabels[this.tab]
    }
  },
  methods: {
    removeCharts() {
      // console.log('clearing charts')
      this.tabLabels.forEach(tab => {
        this.selectedEpws.forEach(epw => {
          epwCharts.clearEPWChart(`${tab}-${epw._id}`)
        })
      })
    },
    refreshCharts() {
      this.removeCharts()
      this.renderCharts()
      this.showCharts(this.tabLabels[this.tab])
    },
    hideCharts(tabName) {
      // console.log('hiding charts for', tabName)
      const svgContainer = document.getElementById(`${tabName}-chart`)
      svgContainer.classList.add('hidden')
    },

    showCharts(tabName) {
      // console.log('showing charts for', tabName)
      const svgContainer = document.getElementById(`${tabName}-chart`)
      svgContainer.classList.remove('hidden')
    },
    renderCharts() {
      this.tabLabels.forEach(tab => {
        // console.log('rendering chart for', tabName)
        this.selectedEpws.forEach(epw => {
          // console.log('epw', epw.name)
          this.chartsAtTab[tab].forEach(chartFunction => {
            // console.log('chartFunction', chartFunction)
            try {
              chartFunction(epw.object, `${tab}-${epw._id}`)
            } catch (error) {
              this.$set(
                this.chartError,
                `${tab}-${epw._id}-error`,
                `Error occured when rendering ${tab}-${epw._id} chart`
              )
            }
          })
        })
      })
    }
  }
}
</script>
<style>
.svg-container {
  height: 300;
  /* display: inline-block;
  position: relative;
  width: 100%;
  height: 300;
  vertical-align: top;
  overflow: hidden; */
}
.hidden {
  display: none;
}
.displayed {
  display: inline-block;
}

.color-rectangle::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 30px;
  background-color: var(--rectangle-color, #3498db);
  z-index: 0;
}

.color-rectangle {
  position: relative;
  z-index: 1;
}
</style>
