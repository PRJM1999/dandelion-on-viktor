<template>
  <v-dialog v-model="show" max-width="600px" @click:outside="$emit('close')">
    <v-card>
      <v-overlay absolute :value="dandelionBranch && dandelionBranch.isLoading">
        <v-progress-circular indeterminate size="64"></v-progress-circular>
      </v-overlay>
      <v-card-title>Upload your data to speckle</v-card-title>
      <v-card-text class="mt-3">
        <speckleStreamSelect v-model="stream" class="px-0" />
        <v-text-field
          class="mt-5 mx-2"
          :value="generatedUrl || 'Commit your data to generate a commit link!'"
          label="Generated URL"
          readonly
          append-icon="mdi-content-copy"
          @click:append="copyToClipboard"
          :messages="branchMessage"
        ></v-text-field>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn text @click="closeDialog">Close</v-btn>
        <v-btn
          :disabled="!stream || !dandelionBranch || dandelionBranch.isLoading"
          color="primary"
          @click="sendCommitToSpeckle"
          >Commit</v-btn
        >
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  props: {
    showDialog: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      show: false,
      stream: null,
      dandelionBranch: null,
      generatedUrl: null,
      branchMessage: null
    }
  },
  watch: {
    showDialog(newValue) {
      this.show = newValue
    },
    async stream(newStream) {
      this.branchMessage = (await newStream.hasBranch('dandelion'))
        ? ''
        : 'This stream does not have a dandelion branch yet, so your first commit will create one automatically!'
      this.dandelionBranch = newStream.Branch('dandelion')
    }
  },
  computed: {
    ...mapGetters({
      selectedEpwsInStore: 'dandelion/selectedEpws'
    })
  },
  methods: {
    closeDialog() {
      this.$emit('close')
    },
    copyToClipboard() {
      if (this.generatedUrl) {
        const el = document.createElement('textarea')
        el.value = this.generatedUrl
        document.body.appendChild(el)
        el.select()
        document.execCommand('copy')
        document.body.removeChild(el)
        this.$snackbar.show('URL copied to clipboard!', { color: 'green' })
      }
    },
    async sendCommitToSpeckle() {
      //commit message
      const currentDate = new Date()
      const commitMsg = `${currentDate.toLocaleDateString()} ${currentDate.toLocaleTimeString()}`

      try {
        //create a branch if missing
        if (!(await this.dandelionBranch.content)) {
          let branchReply = await this.stream.createBranch(
            'dandelion',
            'R&I Labs weather file analyis tool'
          )

          if (branchReply.errors)
            throw new Error('Speckle replied with error while creating branch')

          this.$snackbar.show('Branch created sucessfully!', { color: 'green' })
        }

        // structure data and mark useful objects for serializing into speckle objects
        const data = {
          data: this.selectedEpwsInStore.map(epw => ({
            ...epw,
            speckle_type: 'Base',
            object: { ...epw.object, speckle_type: 'Base' }
          }))
        }

        //commit
        let reply = await this.dandelionBranch.createCommit(
          data,
          'Base',
          'dandelion',
          commitMsg
        )
        console.log(reply)
        if (reply.writeObjReply.errors)
          throw new Error(
            `Speckle replied with error while creating objects: ${reply.createCommitReply.errors[0].message}`
          )

        if (reply.createCommitReply.errors)
          throw new Error(
            `Speckle replied with error while commiting objects: ${reply.createCommitReply.errors[0].message}`
          )

        this.$snackbar.show('Commited successfully!! 🎉🎉', { color: 'green' })

        //update UI
        await this.dandelionBranch.clearCache()
        this.generatedUrl = `https://speckle.uksouth.cloudapp.azure.com/streams/${this.stream.id}/commits/${reply.createCommitReply.data.commitCreate}`
        console.log('finished comitting')
      } catch (error) {
        console.log(error)
        this.$snackbar.error(error.message, { multiLine: true })
      }
    }
  }
}
</script>
