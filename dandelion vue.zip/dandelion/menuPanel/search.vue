<template>
  <v-combobox
    ref="locationCombobox"
    :autofocus="true"
    :loading="searchLoading"
    v-model="searchString"
    @update:search-input="updateGeoLocResults"
    @change="changeLocation"
    :items="geoLocResults"
    item-text="display_name"
    prepend-icon="mdi-map-marker-radius-outline"
    clearable
    dense
    outlined
    hide-details
    label="Search.."
  >
  </v-combobox>
</template>

<script>
import { debounce } from 'lodash'
import { mapMutations } from 'vuex'
export default {
  data() {
    return {
      searchLoading: false,
      searchString: '',
      geoLocResults: []
    }
  },
  computed: {},
  methods: {
    ...mapMutations({
      setProjectLocation: 'dandelion/setProjectLocation'
    }),
    changeLocation(geolocation) {
      if (!geolocation || !geolocation?.osm_id) return
      this.setProjectLocation({ lat: geolocation.lat, lon: geolocation.lon })
      this.$nextTick(() => {
        this.searchString = ''
        this.geoLocResults = []
        this.$refs.locationCombobox.blur()
      })
    },
    updateGeoLocResults: debounce(function(searchQuery) {
      if (!searchQuery) return []
      this.searchLoading = true
      this.fetchLocationSuggestions(searchQuery).then(
        response => (this.geoLocResults = response.data)
      )
      this.searchLoading = false
    }, 300),

    // async updateSearchSuggestion(searchString) {
    //   debounce(
    //     this.fetchLocationSuggestions(searchString).then(
    //       reply => (this.geoLocResults = reply.data)
    //     ),
    //     500
    //   )
    // },

    async fetchLocationSuggestions(searchQuery) {
      searchQuery = searchQuery.replace(' ', '+')
      let response = await this.$axios
        .get(
          `https://nominatim.openstreetmap.org/search?q=${searchQuery}&format=json`
        )
        .catch(err => console.log(err))
      return response
    }
  }
}
</script>
