<template>
  <div class="mt-3">
    <v-list>
      <v-list-item class="px-0">
        <speckleStreamSelect v-model="stream" />
      </v-list-item>
      <v-list-item class="px-0 mt-2">
        <speckleCommitSelect v-model="commit" :branch="dandelionBranch" />
      </v-list-item>
    </v-list>
    <v-expand-transition>
      <v-list three-line subheader v-if="epwsFromCommit">
        <v-card flat outlined>
          <template v-for="(number, index) in [1, 2, 3]">
            <v-list-item :key="index" disabled>
              <v-list-item-content v-if="epwsFromCommit[index]">
                <v-list-item-title>
                  {{ number }} - {{ epwsFromCommit[index].name }}
                </v-list-item-title>
                <v-list-item-subtitle>
                  {{ epwsFromCommit[index].dataset }}
                  {{ epwsFromCommit[index].period }}
                </v-list-item-subtitle>
                <v-list-item-subtitle>
                  {{ epwsFromCommit[index].source }}
                </v-list-item-subtitle>
              </v-list-item-content>
              <v-list-item-action v-if="epwsFromCommit[index]">
                <v-list-item-action-text>
                  {{
                    `${Math.round(epwsFromCommit[index].distanceToProject)} km`
                  }}
                </v-list-item-action-text>
              </v-list-item-action>
            </v-list-item>
          </template>
        </v-card>
      </v-list>
    </v-expand-transition>
    <v-btn
      block
      color="primary"
      :disabled="!epwsFromCommit"
      @click="loadCommit"
    >
      {{ 'Load commit ' }}
      <v-progress-circular
        v-if="commit && !epwsFromCommit"
        indeterminate
      ></v-progress-circular>
    </v-btn>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  data() {
    return {
      stream: null,
      commit: null,
      dandelionBranch: null,
      rootsBranch: null,
      selectedObject: null,
      epwsFromCommit: null
    }
  },
  watch: {
    async stream(newStream) {
      if (!newStream) return
      this.dandelionBranch = newStream.Branch('dandelion')
      this.rootsBranch = newStream.Branch('roots')
      this.loadProject()
    },
    async commit(newCommit) {
      if (!newCommit) return
      this.epwsFromCommit = null
      this.fetchCommitedObject()
    }
  },
  computed: {
    ...mapGetters({
      selectedEpwsInStore: 'dandelion/selectedEpws',
      project: 'dandelion/project'
    })
  },
  methods: {
    ...mapMutations({
      setProject: 'dandelion/project',
      setSelectedEpws: 'dandelion/setSelectedEpws'
    }),
    async fetchCommitedObject() {
      try {
        const commitObject = await this.commit.loadCommitedObject()
        this.selectedObject = commitObject.speckleObject
        this.epwsFromCommit = commitObject.content.data

        if (!commitObject.content.data)
          throw new Error(`Could not load commited object from speckle`)
      } catch (error) {
        this.epwsFromCommit = null
        console.log(error)
        this.$snackbar.error(`Commit not loaded! ${error.message}`, {
          multiLine: true
        })
      }
    },
    async loadProject() {
      let currentProject = this.project

      try {
        const latestCommitId = (await this.rootsBranch.latestCommit).id
        const latestCommit = await this.rootsBranch.Commit(latestCommitId)
        const latestObject = await latestCommit.loadCommitedObject()

        if (!latestObject)
          throw new Error(`Could not load the project object from speckle`)

        this.setProject({
          ATK_Lat:
            latestObject.content?.data?.ATK_Lat ||
            latestObject.content?.ATK_Lat,
          ATK_Lon:
            latestObject.content?.data?.ATK_Lon ||
            latestObject.content?.ATK_Lon,
          address: {
            // city: 'Oxford',
            // country: 'United Kingdom',
            // suburb: 'City Centre',
            // postcode: 'OX1 2DW'
          }
        })
      } catch (error) {
        this.setProject(currentProject)
        console.error(error)
        this.$snackbar.error(`Project not loaded! ${error.message}`, {
          multiLine: true
        })
      }
    },
    loadCommit() {
      this.setSelectedEpws(this.epwsFromCommit)
      this.$emit('loaded')
      this.resetSelection()
    },

    resetSelection() {
      this.stream = null
      this.commit = null
      this.dandelionBranch = null
      // this.rootsBranch = null

      this.selectedObject = null
      this.epwsFromCommit = null
    },
    resetCommitPreview() {
      this.selectedObject = null
      this.epwsFromCommit = null
    }
  }
}
</script>
