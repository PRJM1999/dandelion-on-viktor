<template>
  <div style="  display: flex; flex-direction: column;">
    <v-card-text class="pa-0 mt-2">
      {{ addressText }}
    </v-card-text>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  data() {
    return {}
  },
  watch: {
    async projectPosition() {
      this.fetchAddress()
    }
  },
  computed: {
    ...mapGetters({
      address: 'dandelion/address',
      projectPosition: 'dandelion/projectPosition'
    }),
    addressText() {
      return [
        this.address.neighbourhood || this.address.suburb,
        this.address.city,
        this.address.country,
        this.address.postcode
      ]
        .filter(Boolean)
        .join(', ')
    }
  },
  methods: {
    ...mapActions({
      fetchAddress: 'dandelion/fetchAddress'
    })
  }
}
</script>
