<template>
  <v-dialog v-model="show" max-width="600px" @click:outside="$emit('close')">
    <v-card>
      <v-card-title>Download epw files to desktop</v-card-title>
      <v-card-text class="mt-3">
        The .epw files you selected can be downloaded onto your laptop. Are you
        sure you want to download them now?
      </v-card-text>

      <v-card-text class="">
        Clicking on the links will open a tab for each .epw file and download a
        .zip that is available on the onebuilding.org website.
      </v-card-text>
      <v-card-text v-for="(epw, index) in selectedEpwsInStore" :key="epw._id">
        <a :href="epw.url" target="_blank">{{ `${index + 1}.${epw.url}` }}</a>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn text @click="closeDialog">Close</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  props: {
    showDialog: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      show: false
    }
  },
  watch: {
    showDialog(newValue) {
      this.show = newValue
    }
  },
  computed: {
    ...mapGetters({
      selectedEpwsInStore: 'dandelion/selectedEpws'
    })
  },
  methods: {
    closeDialog() {
      this.$emit('close')
    }
    // openEpwFileDirectories() {
    //   const downloadLinks = this.selectedEpwsInStore.map(epw => {
    //     const link = document.createElement('a')
    //     link.href = epw.url
    //     link.target = epw._id
    //     return link
    //   })
    //   downloadLinks.forEach((link, index) => {
    //     setTimeout(() => {
    //       link.click()
    //     }, 5000 * index)
    //   })
    //   this.closeDialog()
    // }
    //   this.selectedEpwsInStore.forEach((epw, index) => {
    //     console.log('opening', epw.name)
    //     setTimeout(() => {
    //       window.open(epw.url, epw._id)
    //     }, 5000 * index)
    //   })
    //   this.closeDialog()
    // }
  }
}
</script>
