<template>
  <l-map
    ref="map"
    style="height: 100%; width: 100%; position: sticky !important;"
    :zoom="zoom"
    :center="[projectPosition.lat, projectPosition.lng]"
    :options="{ zoomControl: false }"
  >
    <l-control-scale
      position="topright"
      :imperial="true"
      :metric="false"
    ></l-control-scale>
    <l-control-zoom position="bottomright"></l-control-zoom>
    <l-tile-layer :url="url" />
    <l-circle-marker
      :lat-lng="projectPosition"
      :fillOpacity="0"
      :opacity="0"
      :radius="10"
      ref="popupMarker"
    >
      <l-popup :options="popupOpt">
        <v-card flat>
          <v-card-title>
            {{ clickedStation[0]?.name }}
          </v-card-title>
          <v-card-subtitle class="py-0">
            Position - {{ clickedStation[0]?.lat }},
            {{ clickedStation[0]?.lng }}
          </v-card-subtitle>
          <v-card-subtitle class="pt-0">
            Station WMO - {{ clickedStation[0]?.wmo }}
          </v-card-subtitle>
          <v-divider class="my-2"></v-divider>
          <v-list three-line subheader>
            <v-subheader>
              {{
                `${clickedStation.length} weather ${
                  clickedStation.length ? 'files' : 'file'
                } available:`
              }}
            </v-subheader>
            <v-list-item-group
              :value="selectedEpwIdsAtClickedStation"
              @change="handleEpwSelectionAtClickedStation"
              active-class="primary--text"
              multiple
            >
              <template v-for="(epw, index) in clickedStation">
                <v-list-item :key="index" :value="epw._id">
                  <template v-slot:default="{ active }">
                    <v-list-item-content>
                      <v-list-item-title>
                        {{ epw.dataset }}
                        {{ epw.period }}
                      </v-list-item-title>
                      <v-list-item-subtitle>
                        Number of years:
                        {{ epw.years }}
                      </v-list-item-subtitle>
                      <v-list-item-subtitle>
                        Source {{ epw.source }}
                      </v-list-item-subtitle>
                    </v-list-item-content>
                    <v-list-item-action>
                      <v-icon v-if="!active" color="grey lighten-1">
                        mdi-star-outline
                      </v-icon>
                      <v-icon v-else color="yellow darken-3">
                        mdi-star
                      </v-icon>
                    </v-list-item-action>
                  </template>
                </v-list-item>
              </template>
            </v-list-item-group>
          </v-list>
        </v-card>
      </l-popup>
    </l-circle-marker>
    <l-feature-group ref="stationsInRadius">
      <l-circle-marker
        v-for="(station, key) in stationsInRadius"
        :key="key"
        :ref="key"
        :lat-lng="[station[0].lat, station[0].lng]"
        :color="markerColor(station)"
        :fillColor="markerColor(station)"
        :fillOpacity="0.5"
        :radius="10"
        @click="handleStationClick(station, key)"
      ></l-circle-marker>
    </l-feature-group>
    <l-marker
      ref="projMarker"
      :lat-lng="projectPosition"
      :draggable="true"
      @dragend="updateProjectLocation"
    ></l-marker>
    <l-feature-group>
      <l-circle
        :interactive="false"
        :lat-lng="projectPosition"
        color="gray"
        fillColor="gray"
        :fillOpacity="0.25"
        :opacity="0"
        :radius="radius * 1000"
        ref="projRadiusMarker"
      >
      </l-circle>
    </l-feature-group>
  </l-map>
</template>

<script>
import { mapGetters, mapMutations, mapActions } from 'vuex'
export default {
  data() {
    return {
      popupOpt: { minWidth: 400 },
      zoom: 10,
      url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
      clickedStation: [],
      selectedEpwIdsAtClickedStation: []
    }
  },
  async fetch() {
    try {
      this.fetchEpwList()
    } catch (error) {
      console.error(`Failed to fetch epws with error: ${error}`)
    }
  },
  watch: {
    selectedEpwIdsInStore(newIds) {
      if (!newIds) return
      this.selectedEpwIdsAtClickedStation = this.clickedStation
        .filter(epw => newIds.includes(epw._id))
        .map(epw => epw._id)
    }
  },
  computed: {
    ...mapGetters({
      projectPosition: 'dandelion/projectPosition',
      selectedEpwsInStore: 'dandelion/selectedEpws',
      radius: 'dandelion/epwDisplayRadius',
      stationsInRadius: 'dandelion/epwsInRadius',
      epws: 'dandelion/epwsWithDistance'
    }),
    selectedEpwIdsInStore() {
      // console.log('epwsinStore', this.selectedEpwsInStore)
      return this.selectedEpwsInStore.map(epw => epw._id)
    }
  },
  methods: {
    ...mapMutations({
      addEpwToSelected: 'dandelion/addEpwToSelected',
      removeEpwFromSelected: 'dandelion/removeEpwFromSelected',
      setProjectLocation: 'dandelion/setProjectLocation'
    }),
    ...mapActions({
      fetchEpwList: 'dandelion/fetchEpwList'
    }),
    handleStationClick(station, ref) {
      this.selectedEpwIdsAtClickedStation = station
        .filter(epw => this.selectedEpwIdsInStore.includes(epw._id))
        .map(epw => epw._id)
      this.clickedStation = station
      this.$refs['popupMarker'].mapObject.openPopup([
        station[0].lat,
        station[0].lng
      ])
    },
    handleEpwSelectionAtClickedStation(newVal) {
      let oldVal = this.selectedEpwIdsAtClickedStation
      let globalVal = this.selectedEpwIdsInStore

      if (newVal.length > oldVal.length) {
        // if adding to list
        if (globalVal.length >= 3) {
          //if store is full, change the local selection back to showing whats in the store only
          this.selectedEpwIdsAtClickedStation = this.clickedStation
            .filter(epw => globalVal.includes(epw._id))
            .map(epw => epw._id)
          this.$snackbar.show('Only 3 epw files can be selected at any time', {
            color: 'error'
          })
        } else {
          // store has space so go ahead and add
          let newId = newVal.find(epwId => !oldVal.includes(epwId))
          this.addEpwToSelected(this.epws.find(epw => epw._id == newId))
        }
      } else {
        // if removing from list
        let deletedId = oldVal.find(epwId => !newVal.includes(epwId))
        this.removeEpwFromSelected(deletedId)
      }
    },
    updateProjectLocation(event) {
      const { lat, lng } = event.target.getLatLng()
      this.setProjectLocation({ lat: lat, lon: lng })
    },
    markerColor(station) {
      return station.findIndex(epw =>
        this.selectedEpwIdsInStore.includes(epw._id)
      ) > -1
        ? 'green'
        : 'red'
    }
  }
}
</script>
