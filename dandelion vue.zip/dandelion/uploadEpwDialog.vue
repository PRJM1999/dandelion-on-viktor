<template>
  <v-dialog v-model="show" max-width="600px" @click:outside="$emit('close')">
    <v-card>
      <v-card-title>Upload Epw files from desktop</v-card-title>
      <v-card-text class="mt-3">
        If you would like to add an epw file from dektop, you can upload them by
        using the file browser below.
      </v-card-text>
      <v-file-input
        class="mx-4"
        outlined
        rounded
        placeholder="Select an .epw file"
        accept=".epw"
        @change="addEpwToSelected"
      ></v-file-input>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn text @click="closeDialog">Close</v-btn>
        <v-btn color="primary" @click="loadCustomEpwFile(userSelectedEpw)"
          >Load</v-btn
        >
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  props: {
    showDialog: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      show: false,
      userSelectedEpw: null
    }
  },
  watch: {
    showDialog(newValue) {
      this.show = newValue
    }
  },
  computed: {
    ...mapGetters({
      selectedEpwsInStore: 'dandelion/selectedEpws'
    })
  },
  methods: {
    ...mapActions({
      loadCustomEpwFile: 'dandelion/loadEpwFile'
    }),
    closeDialog() {
      this.$emit('close')
    },
    addEpwToSelected(file) {
      this.userSelectedEpw = file
    }

    // openEpwFileDirectories() {
    //   const downloadLinks = this.selectedEpwsInStore.map(epw => {
    //     const link = document.createElement('a')
    //     link.href = epw.url
    //     link.target = epw._id
    //     return link
    //   })
    //   downloadLinks.forEach((link, index) => {
    //     setTimeout(() => {
    //       link.click()
    //     }, 5000 * index)
    //   })
    //   this.closeDialog()
    // }
    //   this.selectedEpwsInStore.forEach((epw, index) => {
    //     console.log('opening', epw.name)
    //     setTimeout(() => {
    //       window.open(epw.url, epw._id)
    //     }, 5000 * index)
    //   })
    //   this.closeDialog()
    // }
  }
}
</script>
