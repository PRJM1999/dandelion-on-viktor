<template>
  <v-navigation-drawer
    v-model="showMenu"
    class="rounded-drawer px-4"
    absolute
    width="400"
    height="715px"
  >
    <v-list>
      <v-list-item class="px-0">
        <v-list-item-avatar size="60" rounded="0">
          <v-img
            src="https://atkinslabstorage.blob.core.windows.net/icons/dandelion.svg"
          ></v-img>
        </v-list-item-avatar>
        <v-list-item-content>
          <v-list-item-title class="text-h6">
            Dandelion
          </v-list-item-title>
          <v-list-item-subtitle>
            Weather file analysis
          </v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <v-btn
            block
            color="primary"
            @click="selectProjectExpand = !selectProjectExpand"
          >
            Find project
          </v-btn>
        </v-list-item-action>
      </v-list-item>
      <v-list-item class="px-0">
        <dandelionMenuPanelSearch />
      </v-list-item>
      <dandelionMenuPanelAddress />
    </v-list>
    <v-divider class="my-2"></v-divider>
    <v-expand-transition>
      <dandelionMenuPanelProject
        v-show="selectProjectExpand"
        @loaded="selectProjectExpand = !selectProjectExpand"
      />
    </v-expand-transition>
    <v-fade-transition>
      <div v-show="!selectProjectExpand">
        <v-list three-line subheader>
          <v-subheader class="px-0">
            Selected epws ({{ selectedEpwsInStore.length }}/3)
          </v-subheader>
          <v-card flat outlined>
            <template v-for="(number, index) in [1, 2, 3]">
              <v-list-item :key="index">
                <v-list-item-content v-if="selectedEpwsInStore[index]">
                  <v-list-item-title>
                    {{ number }} - {{ selectedEpwsInStore[index].name }}
                  </v-list-item-title>
                  <v-list-item-subtitle>
                    {{ selectedEpwsInStore[index].dataset }}
                    {{ selectedEpwsInStore[index].period }}
                  </v-list-item-subtitle>
                  <v-list-item-subtitle>
                    {{ selectedEpwsInStore[index].source }}
                  </v-list-item-subtitle>
                </v-list-item-content>
                <v-list-item-action v-if="selectedEpwsInStore[index]">
                  <v-list-item-action-text>
                    {{
                      `${Math.round(
                        selectedEpwsInStore[index].distanceToProject
                      )} km`
                    }}
                  </v-list-item-action-text>
                  <v-icon
                    size="18"
                    @click="
                      removeSelectedEpwFromStore(selectedEpwsInStore[index]._id)
                    "
                    color="red darken-3"
                  >
                    mdi-close-circle
                  </v-icon>
                  <v-progress-circular
                    v-if="!selectedEpwsInStore[index].content"
                    indeterminate
                    size="18"
                    :color="
                      selectedEpwsInStore[index].isLoading
                        ? 'primary'
                        : 'rgba(255, 0, 0, 0)'
                    "
                  ></v-progress-circular>
                  <v-icon
                    size="18"
                    v-if="selectedEpwsInStore[index].content"
                    color="green darken-3"
                  >
                    mdi-content-save-check-outline
                  </v-icon>
                </v-list-item-action>
              </v-list-item>
            </template>
          </v-card>
          <v-list-item class="px-0">
            <v-slider
              discrete
              ref="rad"
              label="Radius"
              max="100"
              step="1"
              min="0"
              hide-details
              v-model="radius"
              @mouseup="submitRadiusToStore()"
            >
            </v-slider>
            <span>{{ tempRadius }}</span>
          </v-list-item>
        </v-list>
        <v-btn class="mb-2" color="primary" block @click="selectClosestEpws">
          find closest stations
        </v-btn>
        <v-btn
          v-show="!downloadComplete"
          :disabled="!selectedEpwsInStore.length || !!amountFilesLoading"
          block
          color="primary"
          class="custom-disabled-button"
          @click="downloadEpwsContent"
        >
          {{
            amountFilesLoading
              ? `Loading files... ${selectedEpwsWithNoContent} remaining`
              : 'Load weather data'
          }}
        </v-btn>
        <v-btn
          v-show="downloadComplete"
          block
          color="primary"
          @click="requestAnalysis"
        >
          Run Analysis
        </v-btn>
        <!-- <v-btn block color="primary" @click="">clearAnal</v-btn> -->
      </div>
    </v-fade-transition>
  </v-navigation-drawer>
</template>

<script>
import { mapGetters, mapMutations, mapActions } from 'vuex'
export default {
  props: ['showMenu', 'resetMenu'],
  data() {
    return {
      selectProjectExpand: false,
      drawer: true,
      tempRadius: 25
    }
  },
  watch: {
    selectedEpwsInStore() {
      this.selectProjectExpand = false
    }
  },

  computed: {
    selectedEpwsWithNoContent() {
      return this.selectedEpwsInStore.filter(epw => !epw.content).length
    },
    radius: {
      get() {
        return this.radiusInStore
      },
      set(newVal) {
        this.tempRadius = newVal
      }
    },
    ...mapGetters({
      selectedEpwsInStore: 'dandelion/selectedEpws',
      radiusInStore: 'dandelion/epwDisplayRadius',
      downloadComplete: 'dandelion/filesDownloaded',
      amountFilesLoading: 'dandelion/amountLoading',
      closestEpwsToProject: 'dandelion/closestEpwsToProject',
      projectPosition: 'dandelion/projectPosition'
    })
  },
  methods: {
    ...mapMutations({
      removeSelectedEpwFromStore: 'dandelion/removeEpwFromSelected',
      addEpwToSelected: 'dandelion/addEpwToSelected',
      clearSelectedEpws: 'dandelion/clearSelectedEpws'
    }),
    ...mapActions({
      fetchContentForSelectedEpws: 'dandelion/fetchContentForSelectedEpws',
      requestAnalysisForSelectedEpw: 'dandelion/requestAnalysis'
    }),
    submitRadiusToStore() {
      this.$store.commit('dandelion/epwDisplayRadius', this.tempRadius)
    },
    showResults() {
      this.$emit('showResults')
    },
    selectClosestEpws() {
      this.clearSelectedEpws()
      this.closestEpwsToProject.forEach(epw => {
        this.addEpwToSelected(epw)
      })
    },
    async downloadEpwsContent() {
      this.fetchContentForSelectedEpws()
    },
    requestAnalysis() {
      this.showResults()
      console.log('requesting anal')
      this.requestAnalysisForSelectedEpw()
    }
  }
}
</script>
<style scoped>
::v-deep .v-navigation-drawer__content {
  overflow: hidden;
}
.rounded-drawer {
  border-top-right-radius: 10px !important;
  border-bottom-right-radius: 10px !important;
  border-top-left-radius: 10px !important;
  border-bottom-left-radius: 10px !important;
  margin: 15px;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
  overflow: hidden !important;
}
</style>
