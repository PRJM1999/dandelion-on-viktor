/*-------------------------------------------------------------------------
 * grpahs.js
 * library for plotting radial and flood plots
 *
 *-------------------------------------------------------------------------*/

//general code for making a radial chart

import * as d3 from '~/plugins/dandelion/d3/d3_7.8.5.min.js'

export function floodPlot(
  svgId,
  data,
  units,
  colorRange,
  colorGradient = [],
  legendAsRange = false,
  legendNotes = []
) {
  // define chart variables
  var hoursInDay = 24
  var typicalLeapYear = 2020
  var typicalNonLeapYear = 2021
  // get an example year format from data size
  var typicalYear = data.length == 8760 ? typicalLeapYear : typicalNonLeapYear //if 8760, its leap (eg 2020) otherwise 2021
  // define chart dimensions
  var margin = { top: 5, right: 20, bottom: 25, left: 50, spacing: 20 }
  var width = 1200
  var height = 200
  var legendWidth = legendNotes != 0 ? 200 : 75

  //compute remaining dimensions
  var chartWidth =
    width - margin.left - margin.spacing - legendWidth - margin.right
  var chartHeight = height - margin.top - margin.bottom
  var colWidth = chartWidth / (data.length / hoursInDay) + 0.5 // 0.5 extra to account for no border around rectangles
  var rowHeight = chartHeight / hoursInDay + 0.5 // 0.5 extra to account for no border around rectangles

  //if colorGradient values are not provided, then create an array that fits the data
  if (colorGradient.length == 0) {
    colorGradient = fitDataToColorRange(data, colorRange)
  }

  // define scales to translate between chart values and data
  var yScale = d3
    .scaleTime()
    //default domain - 1 day/24h
    .range([chartHeight, 0])

  var xScale = d3
    .scaleTime()
    .domain([new Date(typicalYear, 0, 1), new Date(typicalYear, 11, 31)]) // define one year period in the correct leap/nonleap format
    .range([0, chartWidth])

  //define color scale
  var colorScale = legendAsRange ? d3.scaleThreshold() : d3.scaleLinear()
  colorScale.domain(colorGradient).range(colorRange)

  //precompute date arrays for efficiency
  const xDates = data.map(
    (d, i) => new Date(typicalYear, 0, Math.floor(i / hoursInDay))
  )
  const yDates = data.map((d, i) => new Date(2000, 0, 1, i % hoursInDay))

  //BUILD CHART
  var chartContainer = d3
    .select(svgId)
    .append('svg')
    .attr('preserveAspectRatio', 'xMidYMid meet') //allows for scaling according to the div container size
    .attr('viewBox', `0 0 ${width} ${height}`) // viewBox handles the scaling by specifying the original size
    .classed('svg-content', true) // links to the css style in dandelion.index

  const chart = chartContainer
    .append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`) //move to respect margins

  //add the x axis
  var xAxis = d3.axisBottom(xScale).tickFormat(d3.timeFormat('%B'))

  chart
    .append('g')
    .attr('transform', `translate(0 ,${chartHeight + 5})`) //move down below chart and add gap of 5px
    .call(xAxis)
    .selectAll('.tick text')
    .style('text-anchor', 'start')
    .attr('x', 6)
    .attr('y', 6)

  //add the y axis
  chart
    .append('g')
    .attr('transform', `translate(-5 ,0)`) // add gap of 5px
    .call(d3.axisLeft(yScale).ticks(d3.timeHour.every(3), '%I %p')) //ticks every 2 of d3.timeHour, with labels 12 clock and Am/Pm label

  //add the rectangles that create the flood plot
  chart
    .selectAll('rect')
    .data(data)
    .enter()
    .append('rect')
    .attr('x', (d, i) => xScale(xDates[i]) + colWidth)
    .attr('y', (d, i) => yScale(yDates[i]) - rowHeight)
    .attr('width', colWidth)
    .attr('height', rowHeight)
    .attr('fill-opacity', 1)
    .attr('fill', d => colorScale(d))
  // .attr('stroke', d => colorScale(d))

  //add the legend
  let xLegendPos = margin.left + chartWidth + margin.spacing
  let yLegendPos = margin.top
  if (legendAsRange) {
    addLegendWithLabelAsRange(
      chartContainer,
      xLegendPos,
      yLegendPos,
      colorScale,
      units,
      chartHeight
    )
  } else {
    addLegend(
      chartContainer,
      xLegendPos,
      yLegendPos,
      colorScale,
      units,
      chartHeight,
      legendNotes
    )
  }

  //for returning HMTL:
  // const serializer = new XMLSerializer()
  // const svgString = serializer.serializeToString(chartContainer.node())
  // console.log('returning', svgString)
  // return svgString
}

export function addLegend(
  chartContainer,
  x,
  y,
  colorScale,
  units,
  legendHeight,
  legendNotes
) {
  //domain is reversed to show legend from max to min rather min to max as its defined
  let colorDomain = colorScale.domain().reverse()
  let colorWidth = 18
  let spacing = 5

  // define y position scales
  let yPosition = d3
    .scaleBand()
    .domain(colorDomain)
    .range([y, legendHeight + y])
    .paddingInner(0)
    //.paddingOuter(1)
    .align(0.5)

  // create legend container
  var legendContainer = chartContainer.append('g')

  // create a group for each entry
  var entries = legendContainer
    .selectAll('g')
    .attr('class', 'legend')
    .data(colorDomain)
    .join('g')
    .attr('transform', (d, i) => `translate(${x}, ${yPosition(d)})`)

  // add a color rectangle to entry group
  var colors = entries
    .append('rect')
    .attr('width', colorWidth)
    .attr('height', yPosition.bandwidth())
    .attr('fill', d => colorScale(d))
    .attr('stroke', 'dimgray')
    .attr('stroke-width', 0.5)

  // add label to entry group
  var labels = entries
    .append('text')
    .attr('x', colorWidth + spacing)
    .attr('y', yPosition.bandwidth() / 2)
    .attr('dy', '0.35em')
    .text((d, i) => `${Math.round(d * 2) / 2} ${units}`) // d*2/2 gives 0.5 rounding
    .style('font-size', 10)

  //add note to entry group
  if (legendNotes != 0) {
    let notes = entries
      .append('text')
      .attr('x', colorWidth + spacing + 25)
      .attr('dx', spacing)
      .attr('y', yPosition.bandwidth() / 2)
      .attr('dy', '0.35em')
      .text((d, i) => legendNotes[i]) // d*2/2 gives 0.5 rounding
      .style('font-size', 10)
  }
}

export function addLegendWithLabelAsRange(
  chartContainer,
  x,
  y,
  colorScale,
  units,
  legendHeight
) {
  //domain is reversed to show legend from max to min rather min to max as its defined
  let colorDomain = colorScale.domain().reverse()
  colorDomain.push(colorDomain[colorDomain.length - 1] - 5)

  let colorWidth = 18
  let spacing = 5

  // define y position scales
  let yPosition = d3
    .scaleBand()
    .domain(colorDomain)
    .range([y, legendHeight + y])
    .paddingInner(0)
    //.paddingOuter(1)
    .align(0.5)

  // create legend container
  var legendContainer = chartContainer.append('g')

  // add a color rectangle to entry group
  var colors = legendContainer
    .selectAll('rect')
    .data(colorDomain)
    .join('rect')
    .attr('transform', (d, i) => `translate(${x}, ${yPosition(d)})`)
    .attr('width', colorWidth)
    .attr('height', yPosition.bandwidth())
    .attr('fill', d => colorScale(d + 2)) // value+1 unit to make sure correct color band is displayed (value sometimes lies over the bounday)
    .attr('stroke', 'dimgray')
    .attr('stroke-width', 0.5)

  // add label to entry group
  var labels = legendContainer
    .selectAll('text')
    .data(colorDomain.slice(0, -1)) //remove last entry as there is less labels than colors
    .join('text')
    .attr('transform', (d, i) => `translate(${x}, ${yPosition(d)})`)
    .attr('x', colorWidth + spacing)
    .attr('y', yPosition.bandwidth())
    .attr('dy', '0.35em')
    .text((d, i) => `${Math.round(d * 2) / 2} ${units}`) // d*2/2 gives 0.5 rounding
    .style('font-size', 10)
}

export function fitDataToColorRange(data, colorRange) {
  //fit data to requested colors
  //calculate the value (or limit) for each color and push each value into array
  //if only two colors requested, return min max only and scale will handle it
  let dataMin = d3.min(d3.extent(data))
  let dataMax = d3.max(d3.extent(data))
  let extent = dataMax - dataMin
  let gradientStep = extent / (colorRange.length - 1) // -1 to give correct stepping between min and max
  let gradientValues = Array(colorRange.length)
  gradientValues = gradientValues
    .fill()
    .map((x, i) => dataMin + i * gradientStep)
  // if 2 colors provided, then only min max can be used
  if (colorRange.length == 2) {
    gradientValues = [dataMin, dataMax]
  }
  return gradientValues
}
