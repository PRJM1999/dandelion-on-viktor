import * as d3 from '~/plugins/dandelion/d3/d3_legacy.min.js'

export function getDataByField(weatherData, fieldIndex) {
  //field 5 is uncertainty data and is not a number so retain type
  if (fieldIndex == 5)
    return weatherData.reduce((data, row) => {
      data.push(row[fieldIndex])
      return data
    }, [])

  //for all other fields, convert to Int
  return weatherData.reduce((data, row) => {
    data.push(+row[fieldIndex])
    return data
  }, [])
}

export function parseEpw(raw) {
  var epw_raw = d3.csv.parseRows(raw)

  var epw = {
    _location: {},
    designCondition: {},
    designConditions: {},
    typicalExtremePeriod: {},
    typicalExtremePeriods: {},
    groundTemperature: {},
    groundTemperatures: {},
    holiday: {},
    holidayDaylightSavings: {},
    comments1: {},
    comments2: {},
    dataPeriod: {},
    weatherData: []
  }

  //import location data on first line. example:
  //LOCATION,Denver Centennial  Golden   Nr,CO,USA,TMY3,724666,39.74,-105.18,-7.0,1829.0
  epw._location = epw_raw[0]
  epw.stationLocation = epw_raw[0][1]
  epw.state = epw_raw[0][2]
  epw.country = epw_raw[0][3]
  epw.source = epw_raw[0][4]
  epw.stationID = epw_raw[0][5]
  epw.latitude = epw_raw[0][6]
  epw.longitude = epw_raw[0][7]
  epw.timeZone = epw_raw[0][8]
  epw.elevation = epw_raw[0][9]

  //More header methods can go here

  //DATA PERIOD
  epw.dataPeriod = epw_raw[7]

  //COMMENTS
  epw.comments1 = epw_raw[5]
  epw.comments2 = epw_raw[6]

  //WEATHER DATA
  //remove header and parse weather data into weatherData object
  epw_raw.splice(0, 8)
  // console.log("epw_raw after splicing:", epw_raw)
  //   epw.weatherData = epw_raw

  //data fields in weather data
  let dataFields = [
    'year',
    'month',
    'day',
    'hour',
    'minute',
    'uncertainty',
    'dryBulbTemperature',
    'dewPointTemperature',
    'relativeHumidity',
    'atmosphericStationPressure',
    'extraterrestrialHorizontalRadiation',
    'extraterrestrialDirectNormalRadiation',
    'horizontalInfraredRadiationIntensity',
    'globalHorizontalRadiation',
    'directNormalRadiation',
    'diffuseHorizontalRadiation',
    'globalHorizontalIlluminance',
    'directNormalIlluminance',
    'diffuseHorizontalIlluminance',
    'zenithLuminance',
    'windDirection',
    'windSpeed',
    'totalSkyCover',
    'opaqueSkyCover',
    'visibility',
    'ceilingHeight',
    'presentWeatherObservation',
    'presentWeatherCodes',
    'precipitableWater',
    'aerosolOpticalDepth',
    'snowDepth',
    'daysSinceLastSnowfall',
    'albedo',
    'liquidPrecipitationDepth',
    'liquidPrecipitationQuantity'
  ]

  dataFields.forEach(
    (field, index) => (epw[field] = getDataByField(epw_raw, index))
  )

  // console.log(JSON.stringify(epw))
  return epw
}
