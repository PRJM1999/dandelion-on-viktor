/*-------------------------------------------------------------------------
 * epwCharts.js
 * Chart library for epwvis
 *
 * DEPENDENCIES
 *  - d3.js
 *-------------------------------------------------------------------------*/

import * as legacyCharts from '~/plugins/dandelion/legacyCharts.js'
import * as charts from '~/plugins/dandelion/charts.js'

export function clearEPWCharts() {
  d3.selectAll('svg').remove()
}

export function clearEPWChart(elementId) {
  d3.select(`#${elementId}`)
    .selectAll('*')
    .remove()
}

export function colorPalletePresets() {
  return {
    blueToRed8: [
      'darkblue',
      'blue',
      'cyan',
      'greenyellow',
      'yellow',
      'orange',
      'red',
      'darkred'
    ],
    blueToRed10: [
      '#2c2977',
      '#38429b',
      '#4252a4',
      '#4b62ad',
      '#68b8e7',
      '#53b848',
      'darkorange',
      'red',
      'firebrick',
      'maroon'
    ],
    blueToRed7: [
      '#4252a4',
      '#4b62ad',
      '#68b8e7',
      '#53b848',
      '#ee8522',
      '#ea2b24',
      '#b12224'
    ],
    blueToGray: ['lightskyblue', 'darkslategray'],
    blueToGray11: [
      '#6fdcfb',
      '#6bcde9',
      '#68bfd8',
      '#65b1c7',
      '#62a3b6',
      '#5f95a5',
      '#5b8793',
      '#587982',
      '#556b71',
      '#525d60',
      '#4f4f4f'
    ]
  }
}

export function epwData(epw, value) {
  var month = epw.month
  var day = epw.day
  var hour = epw.hour
  var dayOfYear = []
  var data = []

  for (var i = 0; i < value.length; i++) {
    dayOfYear[i] = Math.floor(i / 24) + 1
    let datum = {
      index: i,
      month: month[i],
      day: day[i],
      hour: hour[i],
      dayOfYear: dayOfYear[i],
      value: value[i]
    }
    data.push(datum)
  }

  //console.log(data);
  return data
}

//unit coversion functions, could be done more cleanly
export function valCtoF(value, index, arr) {
  arr[index] = 32 + value * 1.8
}
export function convertCtoF(array) {
  array.forEach(valCtoF)
  return array
}
export function valKnots(value, index, arr) {
  arr[index] = value * 1.94384
}
export function convertKnots(array) {
  array.forEach(valKnots)
  return array
}

export function epwTempFloodPlot(epw, domId) {
  console.log('printing TempFloodPlot')
  var data = epw.dryBulbTemperature
  var units = '\xB0C'
  var colorRange = colorPalletePresets().blueToRed8
  charts.floodPlot(`#${domId}`, data, units, colorRange)
}

export function epwUTCIFloodPlot(epw, domId) {
  console.log('printing UTCIFloodPlot')
  var data = epw.utciResults.utci
  var units = '\xB0C'
  var colorRange = colorPalletePresets().blueToRed10
  var colorGradient = [-40, -27, -13, 0, 9, 26, 32, 38, 46]
  charts.floodPlot(`#${domId}`, data, units, colorRange, colorGradient, true)
}

export function epwComfortFloodPlot(epw, domId) {
  console.log('printing ComfortFloodPlot')
  var data = epw.utciResults.comfortRating
  var units = ''
  var colorRange = colorPalletePresets().blueToRed7
  var colorGradient = [-3, -2, -1, 0, 1, 2, 3]
  // var legendNotes = [
  //   'High heat stress',
  //   'Med. heat stress',
  //   'Slight heat stress',
  //   'No thermal stress',
  //   'Slight cold stress',
  //   'Med. cold stress',
  //   'High cold stress'
  // ]
  charts.floodPlot(`#${domId}`, data, units, colorRange, colorGradient, false)
}

export function epwRHFloodPlot(epw, domId) {
  console.log('printing RH FloodPlot')
  var data = epw.relativeHumidity
  var units = '%'
  var colorRange = colorPalletePresets().blueToGray11
  var colorGradient = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
  charts.floodPlot(`#${domId}`, data, units, colorRange, colorGradient)
}

export function epwCloudFloodPlot(epw, domId) {
  console.log('printing Cloud cover FloodPlot')
  var data = epw.totalSkyCover
  var units = ''
  var colorRange = colorPalletePresets().blueToGray11
  charts.floodPlot(`#${domId}`, data, units, colorRange)
}

//initialization code for the windrose
export function epwWindRose(epw, domId, unitSystem) {
  var params = {}
  var value = []
  if (unitSystem == 'IP') {
    value = convertKnots(epw.windSpeed)
    params.unit = 'knots'
    params.scale_steps = [3.5, 6.5, 10.5, 16.5, 21.5, 27] //Beaufort scale in knots
    params.steps = 6
  } else {
    value = epw.windSpeed
    params.unit = 'm/s'
    params.scale_steps = [1.8, 3.3, 5.4, 8.5, 11.1, 13.9] //Beaufort scale in m/s
    params.steps = 6
  }

  var data = epwData(epw, value) //encoding most of the object construction here
  var direction = epw.windDirection

  for (var i = 0; i < value.length; i++) {
    data[i].direction = direction[i]
    data[i].directionGroup = Math.round(direction[i] / 22.5)
    if (data[i].directionGroup == 0) {
      //0 and 360 are the same
      data[i].directionGroup = 16
    }
    if (data[i].value == 0) {
      //0 wind speed is 0 group
      data[i].directionGroup = 0
    }
  }

  params.id = `#${domId}`
  params.min_value = 0
  params.max_value = Math.max.apply(Math, value)
  params.length = value.length
  params.directions = 16
  params.labels = [
    'NNE',
    'NE',
    'ENE',
    'E',
    'ESE',
    'SE',
    'SSE',
    'S',
    'SSW',
    'SW',
    'WSW',
    'W',
    'WNW',
    'NW',
    'NNW',
    'N'
  ]
  params.step_colors = [
    '#d73027',
    '#fc8d59',
    '#fee090',
    '#e0f3f8',
    '#91bfdb',
    '#4575b4'
  ]
  params.legend_text = [
    'Light Air',
    'Light Breeze',
    'Gentle Breeze',
    'Moderate Breeze',
    'Fresh Breeze',
    'Strong Breeze'
  ]

  legacyCharts.epwRadialChart(data, params)
}
